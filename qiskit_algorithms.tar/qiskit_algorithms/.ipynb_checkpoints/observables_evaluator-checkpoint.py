# This code is part of a Qiskit project.
#
# (C) Copyright IBM 2021, 2023.
#
# This code is licensed under the Apache License, Version 2.0. You may
# obtain a copy of this license in the LICENSE.txt file in the root directory
# of this source tree or at http://www.apache.org/licenses/LICENSE-2.0.
#
# Any modifications or derivative works of this code must retain this
# copyright notice, and modified files need to carry a notice indicating
# that they have been altered from the originals.

#----------------------------------------------------------------------------------------
# Modified by Alain Chancé April 12, 2025
# Deprecation of BaseSamplerV1 has a conflict with HamiltonianPhaseEstimation class #204
# https://github.com/qiskit-community/qiskit-algorithms/issues/204

# cd $HOME/miniconda3/lib/python3.12/site-packages/qiskit_algorithms
# mv observables_evaluator.py observables_evaluator.py_old.py
# cp $HOME/qiskit_algorithms/observables_evaluator.py observables_evaluator.py
#----------------------------------------------------------------------------------------

"""Evaluator of observables for algorithms."""

from __future__ import annotations
from collections.abc import Sequence
from typing import Any

import numpy as np

from qiskit import QuantumCircuit
from qiskit.quantum_info import SparsePauliOp

#------------------------------------------------------------------------------------------
# Modified by Alain Chancé April 19, 2025

#from qiskit.circuit import QuantumCircuit
#from qiskit.circuit.classicalregister import ClassicalRegister
from qiskit import QuantumCircuit

# https://docs.quantum.ibm.com/api/qiskit/qiskit.primitives.BaseEstimatorV2
# https://docs.quantum.ibm.com/api/qiskit/qiskit.primitives.StatevectorEstimator

from qiskit_algorithms.primitive_version import primitive_v2

# If version 2 of the Qiskit Runtime primitives
if primitive_v2:
    from qiskit.primitives import BaseEstimatorV2 as BaseEstimator, StatevectorEstimator
    print("\nobservables_evaluator.py - Using Sampler V2 primitives")
else:
    from qiskit.primitives import BaseEstimatorV1 as BaseEstimator, EstimatorResult
    print("\nobservables_evaluator.py - Using Sampler V1 primitives")
#------------------------------------------------------------------------------------------


from qiskit.quantum_info.operators.base_operator import BaseOperator

from .exceptions import AlgorithmError
from .list_or_dict import ListOrDict


def estimate_observables(
    estimator: BaseEstimator,
    quantum_state: QuantumCircuit,
    observables: ListOrDict[BaseOperator],
    parameter_values: Sequence[float] | None = None,
    threshold: float = 1e-12,
) -> ListOrDict[tuple[float, dict[str, Any]]]:
    """
    Accepts a sequence of operators and calculates their expectation values - means
    and metadata. They are calculated with respect to a quantum state provided. A user
    can optionally provide a threshold value which filters mean values falling below the threshold.

    Args:
        estimator: An estimator primitive used for calculations.
        quantum_state: A (parameterized) quantum circuit preparing a quantum state that expectation
            values are computed against.
        observables: A list or a dictionary of operators whose expectation values are to be
            calculated.
        parameter_values: Optional list of parameters values to evaluate the quantum circuit on.
        threshold: A threshold value that defines which mean values should be neglected (helpful for
            ignoring numerical instabilities close to 0).

    Returns:
        A list or a dictionary of tuples (mean, metadata).

    Raises:
        AlgorithmError: If a primitive job is not successful.
    """

    if isinstance(observables, dict):
        observables_list = list(observables.values())
    else:
        observables_list = observables

    if len(observables_list) > 0:
        observables_list = _handle_zero_ops(observables_list)
        #-------------------------------------------------------------------------------------------------
        # Modified by Alain Chancé
        # quantum_state = [quantum_state] * len(observables)
        # https://docs.quantum.ibm.com/migration-guides/v2-primitives#estimator-examples-input-and-output
        # 1 circuit, several observables
        if not primitive_v2:
            quantum_state = [quantum_state] * len(observables)
        #-------------------------------------------------------------------------------------------------
        parameter_values_: Sequence[float] | Sequence[Sequence[float]] | None = parameter_values
        if parameter_values is not None:
            parameter_values_ = [parameter_values] * len(observables)

        try:
            #--------------------------------------------------------------------------------------------------------------
            # Modified by Alain Chancé April 19 2025
            if primitive_v2:
                # An estimator pub is essentially a tuple ``(circuit, observables, parameter_values, precision)``
                pub = (quantum_state, observables_list, parameter_values_)
                # estimator_job = estimator.run(quantum_state, observables_list, parameter_values_)
                estimator_job = estimator.run([pub])
                estimator_result = estimator_job.result()[0]
                expectation_values = estimator_result.data.evs
                    
            else:
                estimator_job = estimator.run(quantum_state, observables_list, parameter_values_)
                expectation_values = estimator_job.result().values
        except Exception as exc:
            #--------------------------------------------------------------------------------------------------------------
            # Modified by Alain Chancé April 19 2025
            #raise AlgorithmError("The primitive job failed!") from exc
            print("observables_evaluator.py - estimate_observables - The primitive job to evaluate observables failed!")
            
            print("\nquantum_state")
            print(quantum_state)
            
            print("\nobservables_list")
            print(observables_list)

            print("\nparameter_values")
            print(parameter_values)

            return
            #--------------------------------------------------------------------------------------------------------------

        metadata = estimator_job.result().metadata
        # Discard values below threshold
        observables_means = expectation_values * (np.abs(expectation_values) > threshold)
        # zip means and metadata into tuples
        observables_results = list(zip(observables_means, metadata))
    else:
        observables_results = []

    return _prepare_result(observables_results, observables)


def _handle_zero_ops(
    observables_list: list[BaseOperator],
) -> list[BaseOperator]:
    """Replaces all occurrence of operators equal to 0 in the list with an equivalent ``SparsePauliOp``
    operator."""
    if observables_list:
        zero_op = SparsePauliOp.from_list([("I" * observables_list[0].num_qubits, 0)])
        for ind, observable in enumerate(observables_list):
            if observable == 0:
                observables_list[ind] = zero_op
    return observables_list


def _prepare_result(
    observables_results: list[tuple[float, dict]],
    observables: ListOrDict[BaseOperator],
) -> ListOrDict[tuple[float, dict[str, Any]]]:
    """
    Prepares a list of tuples of eigenvalues and metadata tuples from
    ``observables_results`` and ``observables``.

    Args:
        observables_results: A list of tuples (mean, metadata).
        observables: A list or a dictionary of operators whose expectation values are to be
            calculated.

    Returns:
        A list or a dictionary of tuples (mean, metadata).
    """

    observables_eigenvalues: ListOrDict[tuple[float, dict]]

    if isinstance(observables, list):
        observables_eigenvalues = []
        for value in observables_results:
            observables_eigenvalues.append(value)

    else:
        observables_eigenvalues = {}
        for key, value in zip(observables.keys(), observables_results):
            observables_eigenvalues[key] = value

    return observables_eigenvalues
