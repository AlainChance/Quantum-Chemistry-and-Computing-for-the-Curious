#--------------------------------------------------------------------------------------------
# Created by Alain Chancé April 13, 2025
#
# cd $HOME/miniconda3/lib/python3.12/site-packages/qiskit_algorithms/
# cp $HOME/qiskit_algorithms/primitive_version.py primitive_version.py
#--------------------------------------------------------------------------------------------

# If the version 2 of the Qiskit Runtime primitives is to be used, then set primitive_v2 to True
primitive_v2 = False